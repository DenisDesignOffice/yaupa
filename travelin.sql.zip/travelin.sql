-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 17, 2015 at 03:05 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `travelin`
--

-- --------------------------------------------------------

--
-- Table structure for table `bank_transactions`
--

CREATE TABLE `bank_transactions` (
  `id` int(15) NOT NULL auto_increment,
  `bank` varchar(30) NOT NULL,
  `debit_trans_pin` varchar(50) NOT NULL,
  `deposit_slip_no` varchar(30) NOT NULL,
  `name_of_depositor` varchar(60) NOT NULL,
  `date_of_payment` varchar(12) NOT NULL,
  `amount` int(15) NOT NULL,
  `phone` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `debit_trans_pin` (`debit_trans_pin`,`deposit_slip_no`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `bank_transactions`
--

INSERT INTO `bank_transactions` (`id`, `bank`, `debit_trans_pin`, `deposit_slip_no`, `name_of_depositor`, `date_of_payment`, `amount`, `phone`) VALUES
(1, 'diamond', '', '12345', 'christian', '2015-07-18', 3000, 987654),
(2, 'diamond', '', '123456', '', '20-07-2015', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `booking_records`
--

CREATE TABLE `booking_records` (
  `id` int(15) NOT NULL auto_increment,
  `firstname` varchar(60) NOT NULL,
  `lastname` varchar(60) NOT NULL,
  `email` varchar(60) NOT NULL,
  `phone` int(11) NOT NULL,
  `payment_date` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `traveling_date` date NOT NULL,
  `next_of_kin` varchar(60) NOT NULL,
  `mode_of_payment` varchar(20) NOT NULL,
  `reg_pin` varchar(60) NOT NULL,
  `serial` int(9) NOT NULL,
  `transport_company` varchar(60) NOT NULL,
  `amount_paid` int(14) NOT NULL,
  `status` varchar(25) NOT NULL default 'pending',
  `destination` varchar(60) NOT NULL,
  `bank_slip_no` int(25) NOT NULL,
  `bank_of_payment` varchar(25) NOT NULL,
  `debit_trans_no` varchar(26) NOT NULL,
  `name_of_depositor` varchar(50) NOT NULL,
  `date_of_deposition` date NOT NULL,
  `address` varchar(50) NOT NULL,
  `source` varchar(70) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=179 ;

--
-- Dumping data for table `booking_records`
--

INSERT INTO `booking_records` (`id`, `firstname`, `lastname`, `email`, `phone`, `payment_date`, `traveling_date`, `next_of_kin`, `mode_of_payment`, `reg_pin`, `serial`, `transport_company`, `amount_paid`, `status`, `destination`, `bank_slip_no`, `bank_of_payment`, `debit_trans_no`, `name_of_depositor`, `date_of_deposition`, `address`, `source`) VALUES
(164, 'christian', 'abraham', 'chief@yahoo.com', 2147483647, '2015-07-19 01:10:43', '0000-00-00', 'johna', 'Bank_Deposit', '400003024', 241424, 'King Koko', 3200, 'pending', 'yenagoa - abuja', 12345, '-', '', ' ', '2015-07-18', 'tombia roundabout', ''),
(165, 'christian', 'abraham', 'chief@yahoo.com', 2147483647, '2015-07-19 01:14:48', '0000-00-00', 'johna', 'Bank_Deposit', '410422233', 451441, 'King Koko', 3200, 'pending', 'yenagoa - abuja', 12345, 'Diamond', '', 'christian okpakpo', '2015-07-18', 'tombia roundabout', ''),
(166, 'christian', 'abraham', 'chief@yahoo.com', 2147483647, '2015-07-19 01:22:48', '0000-00-00', 'johna', 'Bank_Deposit', '001122113', 421213, 'King Koko', 3200, 'pending', 'yenagoa - abuja', 12345, 'Diamond', '', 'christian okpakpo', '2015-07-18', 'tombia roundabout', ''),
(167, 'christian', 'abraham', 'chief@yahoo.com', 2147483647, '2015-07-19 01:23:14', '0000-00-00', 'johna', 'Bank_Deposit', '341233032', 212231, 'King Koko', 3200, 'pending', 'yenagoa - abuja', 12345, 'Diamond', '', 'christian okpakpo', '2015-07-18', 'tombia roundabout', ''),
(168, '', '', '', 0, '2015-07-20 23:37:25', '0000-00-00', '', 'Bank_Deposit', '300420223', 534542, 'King Koko', 3200, 'pending', 'yenagoa - abuja', 123456, '-', '', ' ', '0000-00-00', '', ''),
(169, '', '', '', 0, '2015-07-21 05:07:02', '0000-00-00', '', 'Bank_Deposit', '302042134', 225143, 'King Koko', 3200, 'pending', 'yenagoa - abuja', 123456, '-', '', ' ', '0000-00-00', '', ''),
(170, '', '', '', 0, '2015-07-21 09:19:51', '0000-00-00', '', 'Bank_Deposit', '134114400', 446141, 'King Koko', 3200, 'pending', 'yenagoa - abuja', 123456, '-', '', ' ', '0000-00-00', '', ''),
(171, '', '', '', 0, '2015-07-22 11:38:47', '0000-00-00', '', 'Bank_Deposit', '043024323', 332454, 'King Koko', 3200, 'pending', 'yenagoa - abuja', 123456, '-', '', ' ', '0000-00-00', '', ''),
(172, 'christian', 'okpakpo', 'christianokpo@yahoo.com', 2147483647, '2015-07-22 12:00:29', '0000-00-00', 'xtian', 'Bank_Deposit', '003140324', 316614, 'King Koko', 3200, 'pending', 'yenagoa - abuja', 123456, 'Diamond', '', 'christian okpakpo', '0000-00-00', '32 gwegwe street ovom yenagoa', ''),
(173, '', '', '', 0, '2015-07-22 13:49:07', '0000-00-00', '', 'Bank_Deposit', '104120240', 425215, 'King Koko', 3200, 'pending', 'yenagoa - abuja', 123456, '-', '', 'jonah tarila', '0000-00-00', '', ''),
(174, '', '', '', 0, '2015-07-23 06:58:53', '0000-00-00', '', 'Bank_Deposit', '231232321', 535423, 'King Koko', 3200, 'pending', 'yenagoa - abuja', 123456, '-', '', ' ', '0000-00-00', '', ''),
(175, '', '', '', 0, '2015-07-23 23:13:55', '0000-00-00', '', 'Bank_Deposit', '040200320', 332435, 'Sunny Eru', 2700, 'pending', 'yenagoa - lagos', 123456, '-', '', ' ', '0000-00-00', '', ''),
(176, 'christian', 'okpakpo', 'christianokpo@yahoo.com', 87654, '2015-07-23 23:30:35', '0000-00-00', '', 'Bank_Deposit', '131444433', 442564, 'Sunny Eru', 2700, 'pending', 'yenagoa - lagos', 123456, '-', '', ' ', '0000-00-00', '', ''),
(177, '', '', '', 0, '2015-07-24 14:11:23', '0000-00-00', '', 'Bank_Deposit', '421032402', 525165, 'King Koko', 3200, 'pending', 'yenagoa - abuja', 123456, '-', '', 'christian okpakpo', '0000-00-00', '', ''),
(178, 'christian', 'okpakpo', 'christianokpo@yahoo.com', 2147483647, '2015-09-16 10:41:39', '0000-00-00', '', 'Bank_Deposit', '024324340', 662656, 'First Investment', 4100, 'pending', 'Yenagoa - Lagos', 123456, 'First Bank', '', 'christian okpakpo', '0000-00-00', '32 gwegwe street ovom yenagoa', '');

-- --------------------------------------------------------

--
-- Table structure for table `charter`
--

CREATE TABLE `charter` (
  `id` int(15) NOT NULL auto_increment,
  `company_id` int(15) NOT NULL,
  `vehicle_type` varchar(45) NOT NULL,
  `location` varchar(50) NOT NULL,
  `location_state` varchar(50) NOT NULL,
  `destination` varchar(50) NOT NULL,
  `destination_state` varchar(50) NOT NULL,
  `to_cost` int(15) NOT NULL,
  `to_and_fro_cost` int(15) NOT NULL,
  `processing_fee` int(15) NOT NULL,
  `service_hours` varchar(15) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `company_id` (`company_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `charter`
--

INSERT INTO `charter` (`id`, `company_id`, `vehicle_type`, `location`, `location_state`, `destination`, `destination_state`, `to_cost`, `to_and_fro_cost`, `processing_fee`, `service_hours`) VALUES
(1, 1, 'coaster bus', 'yenagoa', 'bayelsa', 'eleme', 'Rivers State', 40000, 70000, 500, '12hours'),
(2, 1, 'Sienna Van', 'Yenagoa', 'Bayelsa', '', 'Rivers', 7000, 13000, 500, '18hrs'),
(3, 1, 'Pickup Van', 'Yenagoa', 'Bayelsa', '', 'Rivers', 15000, 25000, 500, ''),
(4, 0, 'Sienna Van', '', 'Bayelsa', '', 'Rivers', 10000, 18000, 200, '12'),
(5, 0, '', '', '', '', '', 0, 0, 200, ''),
(6, 0, 'Coaster Bus', '', 'Bayelsa', '', 'Lagos', 50000, 80000, 500, '18hours');

-- --------------------------------------------------------

--
-- Table structure for table `charter_booking_records`
--

CREATE TABLE `charter_booking_records` (
  `id` int(15) NOT NULL auto_increment,
  `firstname` varchar(60) NOT NULL,
  `lastname` varchar(60) NOT NULL,
  `email` varchar(60) NOT NULL,
  `phone` int(11) NOT NULL,
  `address` varchar(60) NOT NULL,
  `vehicle_type` varchar(60) NOT NULL,
  `location` varchar(60) NOT NULL,
  `location_state` varchar(60) NOT NULL,
  `destination` varchar(60) NOT NULL,
  `destination_state` varchar(60) NOT NULL,
  `to_cost` int(9) NOT NULL,
  `to_and_fro_cost` int(9) NOT NULL,
  `processing_fee` int(9) NOT NULL,
  `amount_paid` int(9) NOT NULL,
  `payment_date` date NOT NULL,
  `bank_deposit_no` int(9) NOT NULL,
  `debit_no` varchar(9) NOT NULL,
  `name_of_depositor` varchar(60) NOT NULL,
  `company_name` varchar(60) NOT NULL,
  `status` varchar(9) NOT NULL default 'pending',
  `reg_pin` int(10) NOT NULL,
  `serial` int(9) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `serial` (`serial`),
  UNIQUE KEY `reg_pin` (`reg_pin`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=38 ;

--
-- Dumping data for table `charter_booking_records`
--

INSERT INTO `charter_booking_records` (`id`, `firstname`, `lastname`, `email`, `phone`, `address`, `vehicle_type`, `location`, `location_state`, `destination`, `destination_state`, `to_cost`, `to_and_fro_cost`, `processing_fee`, `amount_paid`, `payment_date`, `bank_deposit_no`, `debit_no`, `name_of_depositor`, `company_name`, `status`, `reg_pin`, `serial`) VALUES
(1, '', '', '', 0, '', 'coaster bus', 'yenagoa', 'bayelsa', '', 'Rivers State', 40000, 70000, 0, 0, '0000-00-00', 123456, '', '', 'Sunny Eru', 'pending', 200001124, 225425),
(2, 'christian', 'opakpo', 'christianokpakpo@yahoo.com', 98765, '', 'coaster bus', 'yenagoa', 'bayelsa', '', 'Rivers State', 40000, 70000, 0, 0, '0000-00-00', 123456, '', '', 'Sunny Eru', 'pending', 413032444, 365344),
(3, 'christian', 'okpakpo', 'christianokpakpo@yahoo.com', 2147483647, '', 'coaster bus', 'yenagoa', 'bayelsa', '', 'Rivers State', 40000, 70000, 0, 0, '0000-00-00', 123456, '', '', 'Sunny Eru', 'pending', 341342000, 413662),
(4, '', '', '', 0, '', 'coaster bus', 'yenagoa', 'bayelsa', '', 'Rivers State', 40000, 70000, 0, 0, '0000-00-00', 123456, '', '', 'Sunny Eru', 'pending', 40323130, 214645),
(5, '', '', '', 0, '', 'coaster bus', 'yenagoa', 'bayelsa', '', 'Rivers State', 40000, 70000, 0, 0, '0000-00-00', 123456, '', '', 'Sunny Eru', 'pending', 131310333, 424166),
(6, '', '', '', 0, '', 'coaster bus', 'yenagoa', 'bayelsa', '', 'Rivers State', 40000, 70000, 0, 0, '0000-00-00', 123456, '', '', 'Sunny Eru', 'pending', 401221400, 632152),
(7, '', '', '', 0, '', 'coaster bus', 'yenagoa', 'Bayelsa', '', 'Rivers State', 40000, 70000, 0, 0, '0000-00-00', 123456, '', '', 'Sunny Eru', 'pending', 204100234, 142143),
(8, '', '', '', 0, '', 'coaster bus', 'Yenagoa', 'Bayelsa', '', 'Rivers State', 40000, 70000, 0, 0, '0000-00-00', 123456, '', '', 'Sunny Eru', 'pending', 332244240, 525416),
(9, '', '', '', 0, '', 'coaster bus', 'Yenagoa', 'Bayelsa', '', 'Rivers State', 40000, 70000, 0, 0, '0000-00-00', 123456, '', '', 'Sunny Eru', 'pending', 431004231, 326562),
(10, 'christian', 'okpakpo', 'christianokpakpo@yahoo.com', 2147483647, '', 'coaster bus', 'Yenagoa', 'Bayelsa', '', 'Rivers State', 40000, 70000, 0, 0, '0000-00-00', 123456, '', 'christian', 'Sunny Eru', 'pending', 33131312, 235446),
(11, '', '', '', 0, '', 'coaster bus', 'Yenagoa', 'Bayelsa', '', 'Rivers State', 40000, 70000, 0, 0, '0000-00-00', 123456, '', '', 'Sunny Eru', 'pending', 224403212, 444633),
(12, '', '', '', 0, '', 'coaster bus', 'Yenagoa', 'Bayelsa', 'Eleme', 'Rivers State', 40000, 70000, 0, 0, '0000-00-00', 123456, '', '', 'Sunny Eru', 'pending', 304332030, 611355),
(13, '', '', '', 0, '', 'coaster bus', 'Yenagoa', 'Bayelsa', 'Eleme', 'Rivers State', 40000, 70000, 0, 0, '0000-00-00', 123456, '', '', 'Sunny Eru', 'pending', 344201421, 124331),
(14, 'christian', 'okpakpo', 'christianokpakpo@yahoo.com', 2147483647, '', 'coaster bus', 'Yenagoa', 'Bayelsa', 'Eleme', 'Rivers State', 40000, 70000, 0, 0, '0000-00-00', 123456, '', 'john', 'Sunny Eru', 'pending', 112240142, 661463),
(15, '', '', '', 0, '', 'coaster bus', 'Yenagoa', 'Bayelsa', 'Eleme', 'Rivers State', 40000, 70000, 0, 0, '0000-00-00', 123456, '', '', 'Sunny Eru', 'pending', 420242104, 155266),
(16, 'christian', 'okpakpo', '', 0, '', 'coaster bus', 'Yenagoa', 'Bayelsa', 'Eleme', 'Rivers State', 40000, 70000, 0, 0, '0000-00-00', 123456, '', '', 'Sunny Eru', 'pending', 414333242, 223435),
(17, '', '', '', 0, 'imgbi road amarata', '', '', '', '', '', 0, 0, 0, 0, '0000-00-00', 123456, '', '', 'King Koko', 'pending', 202243244, 545661),
(18, '', '', '', 0, 'imgbi road amarata', '', ',  ', '', '', '', 0, 0, 0, 0, '0000-00-00', 123456, '', '', 'King Koko', 'pending', 313423100, 463356),
(19, '', '', '', 0, 'imgbi road amarata', '', ',  ,  ', '', '', '', 0, 0, 0, 0, '0000-00-00', 123456, '', '', 'King Koko', 'pending', 400142331, 235225),
(20, '', '', '', 0, 'imgbi road amarata', '', ',  ,  ,  ', '', '', '', 0, 0, 0, 0, '0000-00-00', 123456, '', '', 'King Koko', 'pending', 420102242, 232526),
(21, '', '', '', 0, 'imgbi road amarata', '', ',  ,  ,  ,  ', '', '', '', 0, 0, 0, 0, '0000-00-00', 123456, '', '', 'King Koko', 'pending', 340102300, 543454),
(22, '', '', '', 0, 'imgbi road amarata', '', '', '', '', '', 0, 0, 0, 0, '0000-00-00', 123456, '', '', 'King Koko', 'pending', 331344210, 461644),
(23, '', '', '', 0, 'imgbi road amarata', '', ',  ', '', '', '', 0, 0, 0, 0, '0000-00-00', 123456, '', '', 'King Koko', 'pending', 422422244, 256444),
(24, '', '', '', 0, 'imgbi road amarata', '', ',  ,  ', '', '', '', 0, 0, 0, 0, '0000-00-00', 123456, '', '', 'King Koko', 'pending', 320442430, 165564),
(25, '', '', '', 0, 'imgbi road amarata', '', '', '', '', '', 0, 0, 0, 0, '0000-00-00', 123456, '', '', 'King Koko', 'pending', 334340001, 524541),
(26, '', '', '', 0, 'imgbi road amarata', '', '', '', '', '', 0, 0, 0, 0, '0000-00-00', 123456, '', '', 'King Koko', 'pending', 304010010, 215663),
(27, '', '', '', 0, 'imgbi road amarata', '', '', '', '', '', 0, 0, 0, 0, '0000-00-00', 123456, '', '', 'King Koko', 'pending', 422033404, 644552),
(28, '', '', '', 0, 'imgbi road amarata', '', ',  ', '', '', '', 0, 0, 0, 0, '0000-00-00', 123456, '', '', 'King Koko', 'pending', 341140214, 335532),
(29, '', '', '', 0, 'imgbi road amarata', '', ',  ,  ', '', '', '', 0, 0, 0, 0, '0000-00-00', 123456, '', '', 'King Koko', 'pending', 201210443, 142154),
(30, '', '', '', 0, 'imgbi road amarata', '', ',  ,  ,  ', '', '', '', 0, 0, 0, 0, '0000-00-00', 123456, '', '', 'King Koko', 'pending', 441210223, 512412),
(31, 'christian', 'okpakpo', 'christianokpo@yahoo.com', 2147483647, '', 'coaster bus', 'Yenagoa', 'Bayelsa', 'Eleme', 'Rivers State', 40000, 70000, 0, 0, '0000-00-00', 123456, '', 'christian', 'Sunny Eru', 'pending', 103024323, 652336),
(32, '', '', '', 0, '', 'coaster bus', 'Yenagoa', 'Bayelsa', 'Eleme', 'Rivers State', 40000, 70000, 0, 0, '0000-00-00', 123456, '', '', 'Sunny Eru', 'pending', 122004303, 235656),
(33, '', '', '', 0, '', 'coaster bus', 'Yenagoa', 'Bayelsa', 'Eleme', 'Rivers State', 40000, 70000, 0, 0, '0000-00-00', 123456, '', '', 'Sunny Eru', 'pending', 300111042, 561626),
(34, 'christian', 'okpakpo', 'christianokpo@yahoo.com', 2147483647, '', 'coaster bus', 'Yenagoa', 'Bayelsa', 'Eleme', 'Rivers State', 40000, 70000, 0, 0, '0000-00-00', 123456, '', 'christian', 'Sunny Eru', 'pending', 140122234, 351132),
(35, '', '', '', 0, '', 'coaster bus', 'Yenagoa', 'Bayelsa', 'Eleme', 'Rivers State', 40000, 70000, 0, 0, '0000-00-00', 123456, '', '', 'Sunny Eru', 'pending', 241441320, 625224),
(36, 'christian', 'okpakpo', '', 2147483647, '', 'coaster bus', 'Yenagoa', 'Bayelsa', 'Eleme', 'Rivers State', 40000, 70000, 0, 0, '0000-00-00', 123456, '', 'christian', 'Sunny Eru', 'pending', 334311020, 211142),
(37, 'christian', 'okpakpo', 'christianokpo@yahoo.com', 2147483647, '', 'coaster bus', 'Yenagoa', 'Bayelsa', 'Eleme', 'Rivers State', 40000, 70000, 0, 0, '0000-00-00', 123456, '', 'christian', 'Sunny Eru', 'pending', 402212241, 245541);

-- --------------------------------------------------------

--
-- Table structure for table `company_address`
--

CREATE TABLE `company_address` (
  `id` int(15) NOT NULL auto_increment,
  `company_id` int(15) NOT NULL,
  `location` varchar(50) NOT NULL,
  `address` varchar(70) NOT NULL,
  `phone_number` int(15) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `location` (`location`,`address`,`phone_number`),
  UNIQUE KEY `company_id` (`company_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `company_address`
--

INSERT INTO `company_address` (`id`, `company_id`, `location`, `address`, `phone_number`) VALUES
(1, 1, 'Yenagoa', 'Sport complex ovom ', 2147483647),
(2, 2, 'yenagoa', 'imgbi road amarata', 2147483647),
(3, 0, '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `taxi`
--

CREATE TABLE `taxi` (
  `id` int(15) NOT NULL auto_increment,
  `company_id` int(15) NOT NULL,
  `coverage_state` varchar(60) NOT NULL,
  `amount_per_hour` int(15) NOT NULL,
  `amount_half_day` int(15) NOT NULL,
  `amount_full_day` int(15) NOT NULL,
  `location` varchar(60) NOT NULL,
  `coverage_distance` varchar(60) NOT NULL,
  `processing_fee` int(9) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `company_id` (`company_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `taxi`
--

INSERT INTO `taxi` (`id`, `company_id`, `coverage_state`, `amount_per_hour`, `amount_half_day`, `amount_full_day`, `location`, `coverage_distance`, `processing_fee`) VALUES
(1, 2, 'Bayelsa', 2000, 6000, 10000, 'yenagoa', 'yenagoa,ogbia,sabgama', 200);

-- --------------------------------------------------------

--
-- Table structure for table `taxi_booking_details`
--

CREATE TABLE `taxi_booking_details` (
  `id` int(15) NOT NULL auto_increment,
  `company_id` varchar(60) NOT NULL,
  `firstname` varchar(60) NOT NULL,
  `lastname` varchar(60) NOT NULL,
  `coverage_duration` varchar(20) NOT NULL,
  `amount_paid` int(15) NOT NULL,
  `date_of_payment` date NOT NULL,
  `pickup_point` varchar(60) NOT NULL,
  `phone` int(10) NOT NULL,
  `email` varchar(60) NOT NULL,
  `stoppage_point` varchar(60) NOT NULL,
  `name_of_depositor` varchar(60) NOT NULL,
  `deposit_slip_no` int(10) NOT NULL,
  `debit_no` int(20) NOT NULL,
  `date_of_pickup` date NOT NULL,
  `status` varchar(20) NOT NULL default 'pending',
  `pickup_time` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `pin` int(20) NOT NULL,
  `serial` int(20) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `pin` (`pin`,`serial`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `taxi_booking_details`
--

INSERT INTO `taxi_booking_details` (`id`, `company_id`, `firstname`, `lastname`, `coverage_duration`, `amount_paid`, `date_of_payment`, `pickup_point`, `phone`, `email`, `stoppage_point`, `name_of_depositor`, `deposit_slip_no`, `debit_no`, `date_of_pickup`, `status`, `pickup_time`, `pin`, `serial`) VALUES
(1, '2', '', '', 'Bayelsa', 0, '0000-00-00', '', 0, '', '', '', 123456, 0, '0000-00-00', 'pending', '0000-00-00 00:00:00', 402134340, 616442),
(2, '2', 'christian', 'okpakpo', 'Bayelsa', 0, '0000-00-00', '', 2147483647, '', '', '', 123456, 0, '0000-00-00', 'pending', '0000-00-00 00:00:00', 440233043, 365616),
(3, '2', 'christian', 'okpakpo', 'Bayelsa', 0, '0000-00-00', '', 2147483647, '', '', '', 123456, 0, '0000-00-00', 'pending', '0000-00-00 00:00:00', 421044102, 156323),
(4, '2', '', '', 'Bayelsa', 0, '0000-00-00', '', 0, '', '', '', 123456, 0, '0000-00-00', 'pending', '0000-00-00 00:00:00', 143020020, 311566),
(5, '2', '', '', 'Bayelsa', 0, '0000-00-00', '', 0, '', '', '', 123456, 0, '0000-00-00', 'pending', '0000-00-00 00:00:00', 13414410, 556643),
(6, '2', 'christian', 'okpakpo', 'Bayelsa', 0, '0000-00-00', '', 2147483647, 'christianokpo@yahoo.com', '', '', 123456, 0, '0000-00-00', 'pending', '0000-00-00 00:00:00', 13303412, 533562),
(7, '2', '', '', 'Bayelsa', 0, '0000-00-00', '', 0, '', ',  ', '', 123456, 0, '0000-00-00', 'pending', '0000-00-00 00:00:00', 341102310, 324214),
(8, '2', '', '', 'Bayelsa', 0, '0000-00-00', '', 0, '', 'Eleme,  Rivers State', '', 123456, 0, '0000-00-00', 'pending', '0000-00-00 00:00:00', 140213103, 662311),
(9, '2', '', '', 'Bayelsa', 0, '0000-00-00', '', 0, '', 'Eleme,  Rivers State', '', 123456, 0, '0000-00-00', 'pending', '0000-00-00 00:00:00', 114424004, 514454),
(10, '2', '', '', 'Bayelsa', 0, '0000-00-00', '', 0, '', 'Eleme,  Rivers State', '', 123456, 0, '0000-00-00', 'pending', '0000-00-00 00:00:00', 123043322, 641345),
(11, '2', '', '', 'Bayelsa', 0, '0000-00-00', '', 0, '', 'Eleme,  Rivers State', '', 123456, 0, '0000-00-00', 'pending', '0000-00-00 00:00:00', 232034013, 562633),
(12, '2', '', '', 'Bayelsa', 0, '0000-00-00', '', 0, '', 'Eleme,  Rivers State', '', 123456, 0, '0000-00-00', 'pending', '0000-00-00 00:00:00', 402123200, 233624),
(13, '2', '', '', 'Bayelsa', 0, '0000-00-00', '', 0, '', 'Eleme,  Rivers State', '', 123456, 0, '0000-00-00', 'pending', '0000-00-00 00:00:00', 410303212, 422466),
(14, '2', '', '', 'Bayelsa', 0, '0000-00-00', '', 0, '', 'Eleme,  Rivers State', '', 123456, 0, '0000-00-00', 'pending', '0000-00-00 00:00:00', 44221030, 613213),
(15, '2', 'christian', 'okpakpo', 'Bayelsa', 0, '0000-00-00', '', 2147483647, 'christianokpo@yahoo.com', 'Eleme,  Rivers State', '', 123456, 0, '0000-00-00', 'pending', '0000-00-00 00:00:00', 410123430, 212616),
(16, '2', '', '', 'Bayelsa', 0, '0000-00-00', '', 0, '', '', '', 123456, 0, '0000-00-00', 'pending', '0000-00-00 00:00:00', 21003311, 241421);

-- --------------------------------------------------------

--
-- Table structure for table `transport_companies`
--

CREATE TABLE `transport_companies` (
  `id` int(13) NOT NULL auto_increment,
  `company_name` varchar(60) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `company_name` (`company_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `transport_companies`
--

INSERT INTO `transport_companies` (`id`, `company_name`) VALUES
(10, 'Agofure'),
(9, 'AKTC'),
(3, 'Amaxi'),
(8, 'Bayelsa Line'),
(11, 'Edo Line'),
(5, 'First Investment'),
(4, 'God is Good'),
(2, 'King Koko'),
(7, 'Muyi Line'),
(6, 'Peace Mass'),
(1, 'Sunny Eru');

-- --------------------------------------------------------

--
-- Table structure for table `travel_details`
--

CREATE TABLE `travel_details` (
  `id` int(15) NOT NULL auto_increment,
  `company_id` int(15) NOT NULL,
  `fromplace` varchar(60) NOT NULL,
  `toplace` varchar(60) NOT NULL,
  `cost` int(15) NOT NULL,
  `aircondition` varchar(5) NOT NULL,
  `stopage_point` varchar(60) NOT NULL,
  `speed_limit` varchar(6) NOT NULL,
  `last_bus_stop` varchar(50) NOT NULL,
  `duration` varchar(5) NOT NULL,
  `departure_time` time NOT NULL,
  `vehicle_type` varchar(50) NOT NULL,
  `processing_fee` int(15) NOT NULL,
  `vehicle_picture` varchar(300) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `company_id` (`company_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `travel_details`
--

INSERT INTO `travel_details` (`id`, `company_id`, `fromplace`, `toplace`, `cost`, `aircondition`, `stopage_point`, `speed_limit`, `last_bus_stop`, `duration`, `departure_time`, `vehicle_type`, `processing_fee`, `vehicle_picture`) VALUES
(1, 1, 'yenagoa', 'lagos', 2500, 'yes', 'none', '120km/', 'Ikeja', '5hrs', '00:00:06', 'Sienna van', 200, ''),
(2, 2, 'yenagoa', 'abuja', 3000, 'yes', 'Ughelli, Lokoja', '140km/', 'Utaku', '8hr 3', '00:00:06', 'bus', 200, ''),
(3, 1, 'yenagoa', 'port-harcourt', 3000, 'yes', 'none', '120km/', 'mile 1 park', '2hrs', '00:00:08', 'Sienna van', 200, ''),
(4, 2, 'yenagoa', 'lagos', 400, 'yes', 'none', '140km/', 'lekki', '6hrs', '00:00:04', 'coaster bus', 200, ''),
(5, 3, 'Yenagoa', 'Lagos', 4000, 'Yes', 'Ughelli, Oreh', '140km/', 'Ikeja', '8hrs', '00:00:06', 'Coaster', 100, ''),
(6, 4, 'Yenagoa', 'Lagos', 4200, 'No', 'Oreh', '120km/', 'Ikeja', '8hr 3', '00:00:07', 'Sienna Van', 100, ''),
(7, 5, 'Yenagoa', 'Lagos', 4000, 'Yes', 'Ughelli, Oreh', '140km/', 'Ikeja', '8hrs', '00:00:06', 'Coaster', 100, ''),
(8, 6, 'Yenagoa', 'Lagos', 4200, 'No', 'Oreh', '120km/', 'Ikeja', '8hr 3', '00:00:07', 'Sienna Van', 100, ''),
(9, 0, 'yenagoa', 'owerri', 4000, 'Yes', 'None', '', '', '', '00:00:00', '', 0, ''),
(10, 9, 'yenagoa', 'owerri', 4000, 'Yes', 'None', '', '', '', '00:00:00', '', 0, ''),
(11, 9, 'yenagoa', 'Uyo', 4000, 'Yes', 'PortHarcout', '120km/', 'ekot', '4hour', '00:00:00', 'Bus', 100, ''),
(12, 5, 'yenagoa', 'Owerri', 4000, 'Yes', 'None', '120km/', '', '4hour', '00:00:00', 'Bus', 100, ''),
(13, 9, '', '', 0, '', '', '', '', '', '00:00:00', '', 0, ''),
(14, 9, '', '', 0, '', '', '', '', '', '00:00:00', '', 0, ''),
(15, 9, '', '', 0, '', '', '', '', '', '00:00:00', '', 0, ''),
(16, 9, 'yenagoa', 'Lagos', 0, '', '', '', '', '', '00:00:00', '', 0, ''),
(17, 2, 'yenagoa', 'Warri', 1200, 'Yes', 'None', '120km/', 'PTI', '3hour', '00:00:00', 'Bus', 100, ''),
(18, 10, 'yenagoa', 'owerri', 0, '', '', '', '', '', '00:00:00', '', 0, ''),
(19, 3, '', '', 0, '', '', '', '', '', '00:00:00', 'Sienna Van', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(15) NOT NULL auto_increment,
  `username` varchar(40) NOT NULL,
  `password` varchar(40) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`) VALUES
(1, 'john', 'okafor');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `taxi`
--
ALTER TABLE `taxi`
  ADD CONSTRAINT `taxi_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `transport_companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
